-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 10. Mrz 2018 um 16:06
-- Server-Version: 10.1.30-MariaDB
-- PHP-Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `cr14_giava_ferrandina_bigevents`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `startdate` datetime NOT NULL,
  `enddate` datetime NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `capacity` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `URL` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `events`
--

INSERT INTO `events` (`id`, `name`, `startdate`, `enddate`, `description`, `image`, `capacity`, `email`, `phone`, `address`, `URL`, `type`) VALUES
(1, 'Elton John', '2019-05-01 20:30:00', '2019-05-02 23:00:00', 'Elton John gibt aufgrund der ï¿½berwï¿½ltigenden Nachfrage am 1. Mai 2019 ein Zusatz-Konzert in der Wiener Stadthalle. Der Vorverkauf hierfï¿½r startet am Freitag, dem 9. Mï¿½rz 2018 um 10 Uhr.', 'elton-john.jpg', 15, 'concertelton@gmail.com', '0043/01/981000', 'Roland-Rainer-Platz 1, 1150 Wien', 'https://www.stadthalle.com/en/schauen/events/601/Elton-John', 'Music-concert'),
(2, 'Lenny Kravitz', '2018-06-09 20:30:00', '2018-06-09 20:30:00', 'Raise Vibration Tour 2018', 'lenny-crevitz.jpg', 12, 'lenny@gmail.com', '0043/01/981000', 'Roland-Rainer-Platz 1, 1150 Wien', 'https://www.stadthalle.com/en/schauen/events/587/Lenny-Kravitz', 'music'),
(3, 'Superjam-1-Afrika-Tage', '2018-08-21 20:30:00', '2018-08-21 23:30:00', 'Seit 10 Jahren touren Tommy Kaub\'s SUPERJAM europaweit in Clubs und auf Festivals (England, Wales, Portugal, Italien, Frankreich...).', 'Superjam-1-Afrika-Tage-2017-300x196.jpg', 11, 'presse(at)afrika-tage.de', '0043/89/780689', 'Donauinsel, 1210 Wien', 'http://wien.afrika-tage.de/Veranstaltung/superjam/?instance_id=256', 'music'),
(4, 'Yoga in der Galerie', '2018-03-24 17:00:00', '2018-03-24 18:30:00', 'Yoga in der Galerie\r\n(in der Ausstellung \"Stealing Heaven\")\r\n\r\n', 'yoga.jpeg', 9, 'yoga@gmail.com', '0043/01/9560341\r\n', 'Kaiserstraße 76\r\n1070 Wien', 'https://www.falter.at/event/772494/yoga-in-der-galerie', 'Sport'),
(6, 'Die Zauberflï¿½te', '2018-04-08 20:30:00', '2018-04-09 22:30:00', 'Opera by Wolfgang Amadeus Mozart', 'Neu_Zauberfloete3_1.jpg', 7, 'tickets@volksoper.at', '0043/1/513/1/513', 'Währinger Straße 78 \r\n1090 Wien', 'www.volksoper.at', 'theater'),
(7, 'Waldviertelpur ', '2018-05-16 17:30:00', '2018-05-18 21:30:00', '„Best-of“ in Sachen Kulinarik, Kultur, Handwerk und Brauchtum aus dem Waldviertel, NÖ. Mehr als 100 Aussteller bringen all das mit auf den Wiener Rathausplatz.', 'waldviertel-fest-wiener-rathausplatz-09.JPG', 7, 'redaktion@wien-konkret.at ', '0043/01/40008100', 'Rathausplatz 1010 Wien', 'http://www.wiener-rathausplatz.at/programm.html', 'culinary');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user`
--

CREATE TABLE `user` (
  `userId` int(11) NOT NULL,
  `userName` varchar(30) NOT NULL,
  `userEmail` varchar(60) NOT NULL,
  `userPass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `user`
--

INSERT INTO `user` (`userId`, `userName`, `userEmail`, `userPass`) VALUES
(1, 'admin', 'admin@admin.com', '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
