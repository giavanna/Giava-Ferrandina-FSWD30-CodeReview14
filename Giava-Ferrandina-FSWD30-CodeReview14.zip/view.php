<?php
 
  ob_start();
  session_start();

  require_once 'actions/db_connect.php';
 
if($_GET['id']) {
    $id = $_GET['id'];
 
    $sql = "SELECT * FROM events WHERE id = {$id}";
    $result = $conn->query($sql);
 
    $data = $result->fetch_assoc();
 
    $conn->close();
 
?>

<!DOCTYPE html>

<html>

<head>

    <title>View Event</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Coiny" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Dancing+Script|Great+Vibes" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Coiny|Indie+Flower" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="events.css">

    <style type="text/css">
        fieldset {
            margin: auto;
            margin-top: 100px;
            width: 70%;
        }
 
        table tr th {
            padding-top: 20px;
        }
        table th {
            width: 60%;
            border: 1px solid black;
        }
        
    </style>

</head>

<body>
    <div class="container1">
      <div class="row">
        <div>
          <header id="header" class="myheader">
            <h1 id="headerh1"></h1>
          </header>

            <h1 class="h1-top">Global event management company</h1>
 
<fieldset style="color: white;">

    <legend style="color: white;">View Event</legend>

    <div class="view-event">
                          <div class=''>
                              <img src='img/<?php echo $data['image'] ?>' style='width:100%;height:250px;'>
                              <div class='description'>
                                <p>Name : <?php echo $data['name'] ?></p>
                                <p>Address : <?php echo $data['address'] ?></p>
                                <p>Description : <?php echo $data['description'] ?></p>
                                <p>Start date :<?php echo $data['startdate'] ?></p>
                                <p>End date :<?php echo $data['enddate'] ?></p>
                                <p>Capacity : <?php echo $data['capacity'] ?></p>
                                <p>Email :<?php echo $data['email'] ?></p>
                                <p>Phone :<?php echo $data['phone'] ?></p>
                                <p>Url :<?php echo $data['URL'] ?></p>
                                <p>Type :<?php echo $data['type'] ?></p>
                              </div>
                          </div>
       


                <input type="hidden" name="id" value="<?php echo $data['id']?>" />
                <a href="index.php"><button type="button">Back</button></a>

    </div>

</fieldset>

                    <div>
                      <p><a href="#">Back to top</a></p>
                    
                      <footer class="fixed-bottom">
                        <p> &copy; Giava Ferrandina - CodeFactory 2018</p>     
                      </footer>
                    </div> 
              </div>
          </div>
        </div> 
</body>

</html>

 

<?php
}
?>
<?php ob_end_flush(); ?>