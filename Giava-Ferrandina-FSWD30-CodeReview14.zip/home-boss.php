<?php 
	ob_start();
	session_start();

	require_once 'actions/db_connect.php'; 
	
	if (!isset($_SESSION['user'])) header('Location: login.php');

	$res = mysqli_query($conn, "SELECT * FROM user WHERE userId=".$_SESSION['user']);

	$userRow = mysqli_fetch_array($res, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>

    <title>home-boss</title>

	 <link rel="stylesheet" type="text/css" href="events.css">

  <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!-- <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Coiny" rel="stylesheet">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- font -->
  <link href="https://fonts.googleapis.com/css?family=Dancing+Script|Great+Vibes" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Coiny|Indie+Flower" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="events.css">

    <style type="text/css">
        .manageUser {
            width: 50%;
            margin: auto;
        }

        table {
            width: 100%;
            margin-top: 20px;
        }
    </style>

</head>
<body>
	<div class="container1">
        <header id="header" class="myheader">
            <div class="row">
                <div class="col-md-4">
                    <h1 id="headerh1"></h1>
                </div>
            </div>
        </header>
            <h1 class="h1-top">Global event management company</h1>
            
	    <h3 style="color:white">Events</h3>
		    <div class="row">
			    <table border="1" cellspacing="0" cellpadding="0">
			        <tbody>
			      		<?php

			              $sql = "SELECT id, image, name, startdate, enddate, id FROM events";
			              $result = $conn->query($sql);


			              if($result->num_rows > 0) {
			                  while($row = $result->fetch_assoc()) {
			                      echo "<div class='col-md-4'>
			                          <div class=''>
			                            <a href='view.php?id=".$row['id']."'>
			                              <img class='myimg' src='http://localhost/crud/Giava-Ferrandina-FSWD30-CodeReview14/img/".$row['image']."'style='width:100%;height:250px;>
			                              <div class='caption'>
			                                <p>".$row['name']."</p>
			                                <p>".$row['startdate']."</p>
			                                <p>".$row['enddate']."</p>
			                                <a href='update.php?id=".$row['id']."'><button type='button'>Edit</button></a>
				                            <a href='delete.php?id=".$row['id']."'><button type='button'>Delete</button></a> 
			                              </div>
			                            </a>
			                          </div>
			                        </div>";
				                            }
				                        } 
			              	else {
			                  echo "<tr><td colspan='5'><center>No Data Avaliable</center></td></tr>";
			              		}
			            ?>
			        </tbody>
			    </table>

			    	<div class="row">
			    		<a href="create.php">
			    			<button id="aT">Add Event</button>
			    		</a>
			    		<button id="sign-out">
						<a href="logout.php?logout">Sign Out</a>
					</button>
		    		</div>  	
		  	</div>
	  		<span>
			<p>
	            <a href="#">Back to top</a>
	        </p>
	    	</span>
			<div>
				<footer class="fixed-bottom">
				   <p> &copy; Giava Ferrandina - CodeFactory 2018</p>     
				</footer>
			</div>
		</div>	
</body>
</html>